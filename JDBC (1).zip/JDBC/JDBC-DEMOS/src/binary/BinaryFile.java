/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND,MP, 2009-2019
 *
 */
package binary;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class BinaryFile
{
    final static String cmdIns = "insert into jdbcblob values(?,?);";
    final static String cmdSel = "select data from jdbcblob where filename = ?";

    private static byte[] ReadFile(File file) throws FileNotFoundException, IOException
    {
        long length = file.length();
        FileInputStream in = new FileInputStream(file);
        ByteArrayOutputStream out = new ByteArrayOutputStream((int) length);
        byte[] tmp = new byte[1024];
        int len = 0;
        do {
            len = in.read(tmp);
            out.write(tmp, 0, len);
        }
        while (len == tmp.length);
        return  out.toByteArray();
    }

    private static void WriteFile(String name, byte[] data) throws IOException
    {
        File file = new File(name);
        file.createNewFile();

        FileOutputStream out = new FileOutputStream(file);
        out.write(data);
        out.close();
    }
    private static String getFile(String[] args)
    {
        
        if (args.length < 1)
        {
            Usage();
        }
        return args[0];
    }

    private static void Usage()
    {
        System.out.println("Usage: java program <binary-filepath>");
        System.exit(1);
    }
	public static void main(String[] args) throws FileNotFoundException, IOException
	{
        try
		{

			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
            //String url = "jdbc:sqlserver://localhost\\SQlExpress;integratedSecurity=true;databaseName=jdbc";
            
            //Estabelecer a ligacão            
            Connection con = DriverManager.getConnection(url);

            //Handling File
            File file = new File(getFile(args));
            if(!file.exists())
                Usage();
            byte[] tmp = ReadFile(file);

            con.setAutoCommit(false); //para permitir executar o programa várias vezes.
			//obter o statement o comando
			PreparedStatement pstmt = con.prepareStatement(cmdIns);
            pstmt.setString(1, file.getName());
            pstmt.setBytes(2, tmp);
            pstmt.executeUpdate();
            
            //Obter os dados
            pstmt.close();
            pstmt = con.prepareStatement(cmdSel);
            pstmt.setString(1, file.getName());

            ResultSet rs = pstmt.executeQuery();
            rs.next();
            byte[] data = rs.getBytes(1);

            //con.rollback(); //Para permitir correr o programa multiplas vezes.  Para verificarem o que fica na base de dados, substituam o rollback por um commit.
            con.commit();
           
			//fechar o Statement
			pstmt.close();
            rs.close();

			//fechar a ligação
			con.close();

            //escrever o ficheiro para o filesystem
            WriteFile("new_"+file.getName(),data);
		}		
		catch(SQLException sqlex)
		{
			System.out.println(sqlex.getMessage());
		}
	}

    
}
