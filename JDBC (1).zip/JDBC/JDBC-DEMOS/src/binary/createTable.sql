if db_id('jdbc') is null
    create database jdbc;
go
    
USE [jdbc]
GO
if object_id('jdbcblob') is not null
    drop table jdbcblob;
CREATE TABLE jdbcblob
(
	[filename] varchar(260) not null,
	[data] varbinary(8000) not null,
 CONSTRAINT [PK_JDBCBLOBDEMO] PRIMARY KEY([filename])
 )

GO