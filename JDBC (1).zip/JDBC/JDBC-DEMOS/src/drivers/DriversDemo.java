/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND,MP, 2009-2019
 *
 */
package drivers;

public class DriversDemo
{
	public static void main(String args[])
	{

		System.out.println("================ JDBC Driver test =================");
		try
		{
			//Driver JDBC-ODBC Bridge
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			System.out.println("OK for sun.jdbc.odbc.JdbcOdbcDriver");
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println("Error:"+ex.getMessage());
		}

		try
		{
			//Driver postgresql
			Class.forName("org.postgresql.Driver");
			System.out.println("OK org.postgresql.Driver");			
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println("Error:"+ex.getMessage());
		}

		try
		{	
			//Driver Tipo4 para SQLServer
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			System.out.println("Ok for com.microsoft.sqlserver.jdbc.SQLServerDriver");
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println("Error:"+ex.getMessage());
		}
	}
}
