/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND,MP, 2009-2019
 *
 */
package helloworld;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class HelloWorld
{
	public static void main(String[] args) throws SQLException
	{
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
		
			
			//Para JDBC and SQLServer, ver here: http://technet.microsoft.com/en-us/library/ms378988.aspx
			//Para SQL Server: 
			//	- o serviço SQL Browser tem de estar a correr: net start SqlBrowser
			//	- O protocolo TCP-IP tem de estar ligado no SQLServer
                        //      - para utilizar integrated security é necessário especificar o seguinte comando
                        // da máquina virtual java: -Djava.library.path=<directoria para sqljdbc_auth.dll>
			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
			//String url = "jdbc:sqlserver://localhost\\SQlExpress;integratedSecurity=true;databaseName=jdbc";
			

		try
		{
			//Estabelecer a ligacão
			con = DriverManager.getConnection(url);
			
			//executar o comando
			stmt = con.createStatement();
			rs=stmt.executeQuery("select value from JDBCDEMO");
			
			//iterar no resultado
			while(rs.next())
				  System.out.print(rs.getString("value"));
			System.out.println();
		}		
		catch(SQLException sqlex)
		{
			System.out.println("Erro:"+sqlex.getMessage());
		}
        finally 
        {
            //libertar os recursos do ResultSet
            if(rs != null)
                rs.close();
            //libertar os recursos do Statement
			if(stmt != null)
                stmt.close();
			//fechar a ligação
			if(con != null)
                con.close();
        }

		//With java version >= 7, you can use try with resources
		try(Connection con1 = DriverManager.getConnection(url))
		{
			//executar o comando
			try(Statement stmt1 = con1.createStatement())
			{
				try(ResultSet rs1=stmt1.executeQuery("select value from JDBCDEMO"))
				{

					//iterar no resultado
					while (rs1.next())
						System.out.print(rs1.getString("value"));
					System.out.println();
				}//é fechado o recurso
			}//é fechado o recurso
		}//é fechado o recurso
		catch(SQLException sqlex)
		{
			System.out.println("Erro:"+sqlex.getMessage());
		}

    }
}
