if db_id('jdbc') is null
    create database jdbc;
go
    
USE [jdbc]
GO
if object_id('jdbcdemo') is not null
    drop table jdbcdemo;
CREATE TABLE JDBCDEMO
(
	[id] [int] NOT NULL,
	[value] [varchar](50),
 CONSTRAINT [PK_JDBCDEMO] PRIMARY KEY(id)
 )

GO

INSERT INTO JDBCDEMO VALUES(1,'Ola ')
INSERT INTO JDBCDEMO VALUES(2,'Mundo ')
INSERT INTO JDBCDEMO VALUES(3,'do ')
INSERT INTO JDBCDEMO VALUES(4,'JDBC')
INSERT INTO JDBCDEMO VALUES(5,'!')
