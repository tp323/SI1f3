/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND,MP, 2009-2019
 *
 */
package metadata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class Metadata
{
    private static final int TAB_SIZE = 8;

	public static void main(String[] args) throws SQLException
	{
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
		try
		{
            //Definir as credências de ligação
			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
            
            //Estabelecer a ligacão            
            con = DriverManager.getConnection(url);
			
			//executar o comando
			stmt = con.createStatement();
			rs=stmt.executeQuery("select * from JDBCDEMO");
			ResultSetMetaData meta = rs.getMetaData();
            int columnsCount = meta.getColumnCount();
            StringBuffer sep = new StringBuffer("\n");

            //Este código é apenas demonstrativo e só funciona para 
            // as duas colunas existentes na table JDBCDEMO
            for (int i = 1; i <= columnsCount; i++) 
            {
                System.out.print(meta.getColumnLabel(i));
                System.out.print("\t");
                
                for (int j = 0; j < meta.getColumnDisplaySize(i)+TAB_SIZE; j++)
                {
                    sep.append('-');
                
               }
               
            }
            System.out.println(sep);
			
            //iterar no resultado
			while(rs.next())
            {
                //Não é a melhor forma de se fazer.
                //Mas como neste caso o resultado é para ser exclusivamente
                //apresentado na consola, o resultado prático serve
                for (int i = 1; i <= columnsCount; i++)
                {
                    System.out.print(rs.getObject(i));
                    System.out.print("\t");
                }

                System.out.println();
				
            }
			System.out.println();

		}		
		catch(SQLException sqlex)
		{
			System.out.println(sqlex.getMessage());
		}
        finally
        {
            //libertar os recursos do ResultSet
            if(rs != null)
                rs.close();
            //libertar os recursos do Statement
			if(stmt != null)
                stmt.close();
			//fechar a ligação
			if(con != null)
                con.close();
        }
	}
}
