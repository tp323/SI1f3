/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND,MP, 2009-2019
 *
 */
package resultsets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class NullManipulation
{
    final static String cmdSel = "select * from JDBCDEMO union select 9999,null union select null,'Teste int NULL';";
	public static void main(String[] args) throws SQLException
	{

        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
		try
		{
			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
			//String url = "jdbc:sqlserver://localhost\\SQlExpress;integratedSecurity=true;databaseName=jdbc";
			
			//Estabelecer a ligacão            
			con = DriverManager.getConnection(url);
			
			//executar o comando
			stmt = con.createStatement();
			rs=stmt.executeQuery(cmdSel);
			
			//iterar no resultado
			/*while(rs.next())
            {
                int id = rs.getInt(1);
                String value = rs.getString(2);
               //System.out.format("%d\t%s\n", id , value);
               System.out.format("%d\t%d\n", id, value.length());
            }*/

            rs=stmt.executeQuery(cmdSel);
            System.out.println("---------------------");
            while(rs.next())
            {
               int id = rs.getInt(1);
               if ( rs.wasNull())//determina se o valor anteriormente devolvido é null
                   id = -9999;
               String value = rs.getString(2);
               if ( rs.wasNull())
                   value ="???";
               System.out.format("%d\t%s\n", id , value);
            }
			
		}		
		catch(SQLException sqlex)
		{
			System.out.println(sqlex.getMessage());						
		}
        finally
        {
            //livertar o ResultSet
            rs.close();
            //libertar o Statement
			stmt.close();
			//fechar a ligação
			con.close();
        }
	}
}
