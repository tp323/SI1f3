/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND,MP, 2009-2019
 *
 */
package resultsets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class ResultSetEx
{
	public static void main(String[] args) throws SQLException
	{
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
		try
		{
			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
			//String url = "jdbc:sqlserver://localhost\\SQlExpress;integratedSecurity=true;databaseName=jdbc";
			
			//Estabelecer a ligacão            
			con = DriverManager.getConnection(url);
			
			//executar o comando
			stmt = con.createStatement();
			rs=stmt.executeQuery("select id, value from JDBCDEMO");
			
			//iterar no resultado
			while(rs.next())
            {
               System.out.format("%d\t%s\n", rs.getInt(1), rs.getString("value"));
               //System.out.format("%s\t%s\n", rs.getString(1), rs.getString("value"));//Exemplo de coerção de tipo
            }
						
			
		}		
		catch(SQLException sqlex)
		{
			System.out.println(sqlex.getMessage());
		}
        finally
        {
            //livertar o ResultSet
            rs.close();
            //libertar o Statement
			stmt.close();
			//fechar a ligação
			con.close();
        }
	}
}
