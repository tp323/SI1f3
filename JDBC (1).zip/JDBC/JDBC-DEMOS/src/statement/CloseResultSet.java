/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND, 2009-2019
 *
 */
package statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class CloseResultSet
{
	final static String cmdSel = "select value from JDBCDEMO";
	final static String cmdIns = "insert into JDBCDEMO select max(id)+1,'Teste Insert' from JDBCDEMO;";
		
	public static void main(String[] args)
	{
		try
		{
			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
			//String url = "jdbc:sqlserver://localhost\\SQlExpress;integratedSecurity=true;databaseName=jdbc";
			
			//Estabelecer a ligacão            
			Connection con = DriverManager.getConnection(url);
			
			//Obter um statement
			Statement stmt = con.createStatement();
			
			//executar o comando de select
			ResultSet rs = stmt.executeQuery(cmdSel);			
			
			//executar o comando de insert
			stmt.executeUpdate(cmdIns);
			
			//aceder ao ResultSet
			rs.first(); //gera excepção
			
			//fechar o Statement
			stmt.close();			
			//fechar a ligação
			con.close();
		}		
		catch(SQLException sqlex)
		{
			System.out.println(sqlex.getMessage());
		}		
		
	}
}
