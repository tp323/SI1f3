/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND, 2009-2019
 *
 */
package statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class DefaultStatement
{
	final static String cmdIns = "insert into JDBCDEMO select max(id)+1,'Teste ' from JDBCDEMO;";
	final static String cmdSel = "SELECT * from JDBCDEMO;";
	
	public static void main(String[] args)
	{
		 try
		{
			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
			//String url = "jdbc:sqlserver://localhost\\SQlExpress;integratedSecurity=true;databaseName=jdbc";
			
			//Estabelecer a ligacão            
			Connection con = DriverManager.getConnection(url);
			
			//Obter um statement
			Statement stmt = con.createStatement();
			
			//executar o comando de inserção
			stmt.executeUpdate(cmdIns);
			
			//obter os resultados através de um select
			ResultSet rs=stmt.executeQuery(cmdSel);
			
			//iterar no resultado
			while(rs.next())
				  System.out.print(rs.getString("value"));
			System.out.println();
			
			//fechar o Statement
			stmt.close();
			//fechar a ligação
			con.close();
		}		
		catch(SQLException sqlex)
		{
			System.out.println(sqlex.getMessage());
		}	
		
		
	}
}
