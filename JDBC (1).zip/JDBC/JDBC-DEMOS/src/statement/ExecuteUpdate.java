/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND, 2009-2019
 *
 */
package statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class ExecuteUpdate
{
	final static String cmdUpt = "update JDBCDEMO set value='Teste do executeUpdate:';";
	final static String cmdIns = "insert into JDBCDEMO select max(id)+1,'Teste Insert' from JDBCDEMO;";
	final static String cmdDDL = "create table T(i int); drop table T;";
	final static String cmdSel = "SELECT * from JDBCDEMO;";
	
	
	public static void main(String[] args)
	{
		try
		{
			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
			//String url = "jdbc:sqlserver://localhost\\SQlExpress;integratedSecurity=true;databaseName=jdbc";
			
			//Estabelecer a ligacão            
			Connection con = DriverManager.getConnection(url);
			
			//Obter um statement
			Statement stmt = con.createStatement();
			
			//executar o comando de update
			int nTuplos = stmt.executeUpdate(cmdUpt);
			System.out.println("Update:"+nTuplos); // numero de tuplos da tabela
			
			//executar o comando de inserção
			nTuplos = stmt.executeUpdate(cmdIns);
			System.out.println("Insert:"+nTuplos); // 1
			
			//executar o comando de DDL
			nTuplos = stmt.executeUpdate(cmdDDL);
			System.out.println("DDL:"+nTuplos); //0
			
			//obter os resultados através de um select
			ResultSet rs=stmt.executeQuery(cmdSel);

            System.out.println();
			//iterar no resultado
			while(rs.next())
				  System.out.println(rs.getString("value"));
			System.out.println();
			
			//fechar o Statement
			stmt.close();			
			//fechar a ligação
			con.close();
		}		
		catch(SQLException sqlex)
		{
			System.out.println(sqlex.getMessage());
		}		
		
	}
}
