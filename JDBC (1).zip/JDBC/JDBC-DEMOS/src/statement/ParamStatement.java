/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND, 2009-2019
 *
 */
package statement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class ParamStatement
{
	final static String cmdIns = "insert into JDBCDEMO select max(id)+1,? from JDBCDEMO;";
	final static String cmdSel = "SELECT * from JDBCDEMO;";
		
	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		try
		{
			
			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
			//String url = "jdbc:sqlserver://localhost\\SQlExpress;integratedSecurity=true;databaseName=jdbc";
			
			//Estabelecer a ligacão            
			Connection con = DriverManager.getConnection(url);
			
			
			//Obter um statement para o comando parametrizado
			PreparedStatement pstmt = con.prepareStatement(cmdIns);

            //definir os parâmetros
            pstmt.setString(1,"teste com parametros");
			
			//executar o comando de inserção
			pstmt.executeUpdate();
			
			//Obter um statement para o comando select
			Statement stmt = con.createStatement();
			//obter os resultados através de um select
			ResultSet rs=stmt.executeQuery(cmdSel);
			
			//iterar no resultado
			while(rs.next())
				  System.out.println(rs.getString("value"));
			System.out.println();
			
			//fechar o Statement
			stmt.close();
            pstmt.close();
			//fechar a ligação
			con.close();
		}		
		catch(SQLException sqlex)
		{
			System.out.println(sqlex.getMessage());
		}		
		
	}
}
