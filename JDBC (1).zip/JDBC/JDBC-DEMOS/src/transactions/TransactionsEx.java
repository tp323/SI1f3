/**
 *	ISEL-ADEETC
 *	Sistemas de Informação I
 *	ND,MP, 2009-2019
 *
 */
package transactions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TransactionsEx
{
	final static String cmdIns = "insert into JDBCDEMO select max(id)+1,? from JDBCDEMO;";
    final static String cmdSel = "SELECT * from JDBCDEMO;";
    private static String now(String dateFormat)
    {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        return sdf.format(cal.getTime());
    }

	public static void main(String[] args) throws SQLException
	{
		Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
		try
		{
            //obter info do utilizador
            //numero de tuplos a inserir
            int num = (args.length >0 )? Integer.parseInt(args[0]):4;

            //termino da transacção
            boolean commit = (args.length >1)? Boolean.parseBoolean(args[1]):false;

			String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=jdbc";
			//String url = "jdbc:sqlserver://localhost\\SQlExpress;integratedSecurity=true;databaseName=jdbc";
			
			//Estabelecer a ligacão            
			con = DriverManager.getConnection(url);

            //gerar dados
            String time = now("HH:mm:ss");

			//Obter um statement
			PreparedStatement pstmt = con.prepareStatement(cmdIns);
            pstmt.setString(1, time);

            //desligar o auto commit no fim de cada execução !IMPORTANTE
            con.setAutoCommit(false);
            for (int i = 0; i < num ; i++)
                 	pstmt.executeUpdate();

            //terminar de acordo com os argumentos passados ao programa
            if(commit)
                con.commit();
            else
                con.rollback();

            //voltar a ligar o auto commit
            //Apenas é necessário se foram executados novos comandos
            con.setAutoCommit(true);

            //Obter Statement para select
            stmt = con.createStatement();
			//mostrar resultados
			rs=stmt.executeQuery(cmdSel);
			//iterar no resultado
			while(rs.next())
                System.out.format("%d\t%s\n", 
                        rs.getInt(1),rs.getString(2));
			System.out.println();			
		}		
		catch(SQLException sqlex)
		{
			System.out.println(sqlex.getMessage());			
		}
		finally
        {
            //libertar os recursos do ResultSet
            if(rs != null)
                rs.close();
            //libertar os recursos do Statement
			if(stmt != null)
                stmt.close();
			//fechar a ligação
			if(con != null)
			{				
                con.close();
            }
		}
	}
}
