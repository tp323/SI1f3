/** 
ISEL-ADEETC
Sistemas de Informação I
MP,ND, 2014-2019
*/

package jdbc;

import java.sql.*;
import java.util.Scanner;
import java.util.HashMap;

interface DbWorker 
{
	void doWork();
}	
class App
{
	private enum Option
	{
		Unknown,
		Exit,
		ListStudent,
		ListCourse,
		RegisterStudent,
		EnrolStudent
	}
	private static App __instance = null;
	private String __connectionString;
	private HashMap<Option,DbWorker> __dbMethods;
	private Connection con = null;
    private Statement stmt = null;
    private ResultSet rs = null;


	private App()
	{
		__dbMethods = new HashMap<Option,DbWorker>();
		__dbMethods.put(Option.ListStudent, new DbWorker() {public void doWork() {App.this.ListStudent();}});
		__dbMethods.put(Option.ListCourse, new DbWorker() {public void doWork() {App.this.ListCourse();}});
		__dbMethods.put(Option.RegisterStudent, new DbWorker() {public void doWork() {App.this.RegisterStudent();}});
		__dbMethods.put(Option.EnrolStudent, new DbWorker() {public void doWork() {App.this.EnrolStudent();}});

	}
	public static App getInstance() 
	{
		if(__instance == null) 
		{
			__instance = new App();
		}
		return __instance;
	}

	private Option DisplayMenu()
	{ 
		Option option=Option.Unknown;
		try
		{
			System.out.println("Course management");
			System.out.println();
			System.out.println("1. Exit");
			System.out.println("2. List students");
			System.out.println("3. List courses");
			System.out.println("4. Register student");
			System.out.println("5. Enrol student");
			System.out.print(">");
			Scanner s = new Scanner(System.in);
			int result = s.nextInt();
			option = Option.values()[result];			
		}
		catch(RuntimeException ex)
		{
			//nothing to do. 
		}
		
		return option;
		
	}
	private final static void clearConsole() throws Exception
	{
	    for (int y = 0; y < 25; y++) //console is 80 columns and 25 lines
	    System.out.println("\n");

	}
	private void Login() throws java.sql.SQLException
	{

		Connection con = DriverManager.getConnection(getConnectionString());
		if(con != null)
			con.close();      
		
	}
	public void Run() throws Exception
	{
		Login ();
		Option userInput = Option.Unknown;
		do
		{
			clearConsole();
			userInput = DisplayMenu();
			clearConsole();		  	
			try
			{		
				__dbMethods.get(userInput).doWork();		
				System.in.read();		
				
			}
			catch(NullPointerException ex)
			{
				//Nothing to do. The option was not a valid one. Read another.
			}
			
		}while(userInput!=Option.Exit);
	}

	public String getConnectionString() 
	{
		return __connectionString;			
	}
	public void setConnectionString(String s) 
	{
		__connectionString = s;
	}

	/**
		To implement from this point forward. Do not need to change the code above.
	-------------------------------------------------------------------------------		
		IMPORTANT:
	--- DO NOT MOVE IN THE CODE ABOVE. JUST HAVE TO IMPLEMENT THE METHODS BELOW ---
	-------------------------------------------------------------------------------
	
	*/
	private static final int TAB_SIZE = 4;
	private void printResults(ResultSet dr) throws SQLException
	{
		//TODO
		/*Result must be similar like:
		ListStudent()
		id   name           dateBirth      sex            
		----------------------------------------
		1    John           1970-01-21     M              
		2    Joe            1971-07-12     M              
		3    Mary           1969-05-04     F              
		4    Bob            1970-12-12     M              
		5    Zoe            1978-12-12     F        */ 
	}


	private void ListStudent()
	{
		//TODO: Implement
		System.out.println("ListStudent()");
	}        

	private void ListCourse()
	{
		//TODO: Implement
		System.out.println("ListCourse()");
	}
	private void RegisterStudent()
	{
		//TODO: Implement
		System.out.println("RegisterStudent()");
	}
	private void EnrolStudent()
	{
		//TODO: Implement
		System.out.println("EnrolStudent()");
	}
	
}

public class Ap3
{
	public static void main(String[] args) throws SQLException,Exception
	{
			//Source of the JDBC and the SQLServer, here: 
			//	http://technet.microsoft.com/en-us/library/ms378988.aspx
			//Source of SQL Server: 
			//	- the SQL Browser service must be running: net start SqlBrowser
			//	- The TCP-IP protocol must be connected in SQLServer
            //      - to use integrated security you must specify the following command 
            // from the java virtual machine: -Djava.library.path=<directoria para sqljdbc_auth.dll>
			//String url = "jdbc:sqlserver://10.62.73.95:1433;user=jdbcuser;password=jdbcpasswd;databaseName=aula03"; //(1)
            String url = "jdbc:sqlserver://localhost:1433;user=jdbcuser;password=jdbcpasswd;databaseName=aula03";	  //(2)
			
			App.getInstance().setConnectionString(url);
			App.getInstance().Run();
	}
}

/* 
private class Connect {
	private java.sql.Connection con = null;
    private final String url = "jdbc:sqlserver://";
    private final String serverName = "localhost";
    private final String portNumber = "1433";
    private final String databaseName = "aula03";
    private final String userName = "matildepato";
    private final String password = "xxxxxxx";

    // Constructor
    public Connect() {
    }

    private String getConnectionUrl() {
        return url + serverName + ":" + portNumber + ";databaseName=" + databaseName ;
    }

    private java.sql.Connection getConnection() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = java.sql.DriverManager.getConnection(getConnectionUrl(), userName, password);
            if (con != null) {
                System.out.println("Connection Successful!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error Trace in getConnection() : " + e.getMessage());
        }
        return con;
    }

  
    private void closeConnection() {
        try {
            if (con != null) {
                con.close();
            }
            con = null;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
*/ 